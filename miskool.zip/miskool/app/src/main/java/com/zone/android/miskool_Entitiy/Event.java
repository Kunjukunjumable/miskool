package com.zone.android.miskool_Entitiy;

import android.arch.persistence.room.Entity;

/**
 * Created by Inspiron on 23-10-2018.
 */

public class Event {

}
