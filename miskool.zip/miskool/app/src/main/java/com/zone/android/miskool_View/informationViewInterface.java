package com.zone.android.miskool_View;

import com.zone.android.miskool_Entitiy.Person_det;

import java.util.List;

/**
 * Created by Inspiron on 26-03-2018.
 */

public interface informationViewInterface {
    void setList(List<Person_det> person_dets);

}
