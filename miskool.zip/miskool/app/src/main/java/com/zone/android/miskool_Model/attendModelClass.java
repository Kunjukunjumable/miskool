package com.zone.android.miskool_Model;

import android.content.Context;

import com.zone.android.miskool.attendFragmentInterface;

/**
 * Created by Inspiron on 04-10-2018.
 */

public class attendModelClass implements attendModelInterface {
    @Override
    public void getAttendanceDetails(String studentId, Context context, attendFragmentInterface attendFragmentInterface) {

    }
}
