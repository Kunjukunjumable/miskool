package com.zone.android.miskool;

/**
 * Created by Inspiron on 04-10-2018.
 */

public interface attendFragmentInterface {

    void setAttendanceDetails();
}
