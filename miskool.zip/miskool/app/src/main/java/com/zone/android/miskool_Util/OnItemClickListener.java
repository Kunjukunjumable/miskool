package com.zone.android.miskool_Util;

import com.zone.android.miskool_Entitiy.Message_In;
import com.zone.android.miskool_Entitiy.Schedule;

/**
 * Created by Inspiron on 03-04-2018.
 */

public interface OnItemClickListener {
    void onItemClick(Message_In item);

}
