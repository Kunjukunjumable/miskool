package com.zone.android.miskool_Util;

import com.zone.android.miskool_Entitiy.Schedule;

/**
 * Created by Inspiron on 22-10-2018.
 */

public interface scheduleOnclickListner {
    void onItemClickSchedule(Schedule schedule);

}
