package com.zone.android.miskool_Util;

/**
 * Created by Inspiron on 28-06-2018.
 */

public class eventModel {

    String eventSub;
    String eventMsg;
    String EventDate;
    String eventStartTime;
    String eventEndTime;


    public String getEventSub() {
        return eventSub;
    }

    public void setEventSub(String eventSub) {
        this.eventSub = eventSub;
    }

    public String getEventMsg() {
        return eventMsg;
    }

    public void setEventMsg(String eventMsg) {
        this.eventMsg = eventMsg;
    }

    public String getEventDate() {
        return EventDate;
    }

    public void setEventDate(String eventDate) {
        EventDate = eventDate;
    }

    public String getEventStartTime() {
        return eventStartTime;
    }

    public void setEventStartTime(String eventStartTime) {
        this.eventStartTime = eventStartTime;
    }

    public String getEventEndTime() {
        return eventEndTime;
    }

    public void setEventEndTime(String eventEndTime) {
        this.eventEndTime = eventEndTime;
    }



}
