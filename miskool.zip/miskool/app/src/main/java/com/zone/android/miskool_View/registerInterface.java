package com.zone.android.miskool_View;

public interface registerInterface {
    void showMessage(int message);
}
