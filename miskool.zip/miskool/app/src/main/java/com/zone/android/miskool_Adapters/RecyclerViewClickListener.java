package com.zone.android.miskool_Adapters;

import android.view.View;

/**
 * Created by Inspiron on 04-03-2018.
 */

public interface RecyclerViewClickListener {
    public void recyclerViewListClicked(View v, int position);
}
