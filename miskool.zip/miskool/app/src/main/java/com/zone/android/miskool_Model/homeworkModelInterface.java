package com.zone.android.miskool_Model;

import android.content.Context;

import com.zone.android.miskool.homeFragmentInterface;

/**
 * Created by Inspiron on 04-10-2018.
 */

public interface homeworkModelInterface {

    void getHomeDetails(String studenTid, Context context, homeFragmentInterface homeFragmentInterface);
}
