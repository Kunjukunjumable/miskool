package com.zone.android.miskool_View;

/**
 * Created by Inspiron on 20-09-2018.
 */

public interface courseViewInterface {
   void setTimetable();
   void setAttendance();
   void setHomework();
   void setExam();
}
