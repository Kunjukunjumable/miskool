package com.zone.android.miskool_View;

import com.zone.android.miskool_Entitiy.Attributes;
import com.zone.android.miskool_Entitiy.Person_det;

import java.util.List;

/**
 * Created by Inspiron on 17-05-2018.
 */

public interface pagerViewInterface {

    void setAttList(List<Attributes> attList);

}
