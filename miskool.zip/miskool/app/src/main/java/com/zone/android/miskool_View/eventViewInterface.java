package com.zone.android.miskool_View;

/**
 * Created by Inspiron on 23-10-2018.
 */

public interface eventViewInterface {
    void sentResponse(int errorCode);
}
