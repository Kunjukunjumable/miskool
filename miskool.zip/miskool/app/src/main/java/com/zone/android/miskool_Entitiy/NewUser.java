package com.zone.android.miskool_Entitiy;

public class NewUser {
    String userName;
    String password;

}
