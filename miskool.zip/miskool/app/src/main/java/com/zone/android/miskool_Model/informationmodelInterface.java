package com.zone.android.miskool_Model;

import android.content.Context;

import com.zone.android.miskool_Presenter.informationPresInterface;
import com.zone.android.miskool_Presenter.loginPresInterface;

/**
 * Created by Inspiron on 26-03-2018.
 */

public interface informationmodelInterface {

    void getPersonList(informationPresInterface informationPresInterface, Context context);


}
