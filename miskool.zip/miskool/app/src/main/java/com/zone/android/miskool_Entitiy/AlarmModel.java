package com.zone.android.miskool_Entitiy;

/**
 * Created by Inspiron on 16-03-2018.
 */

public class AlarmModel {

    String year,month,dayofmonth,hour,minute,scond;
    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getDayofmonth() {
        return dayofmonth;
    }

    public void setDayofmonth(String dayofmonth) {
        this.dayofmonth = dayofmonth;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getMinute() {
        return minute;
    }

    public void setMinute(String minute) {
        this.minute = minute;
    }

    public String getScond() {
        return scond;
    }

    public void setScond(String scond) {
        this.scond = scond;
    }



}
