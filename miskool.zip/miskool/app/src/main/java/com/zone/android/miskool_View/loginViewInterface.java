package com.zone.android.miskool_View;

/**
 * Created by Inspiron on 13-11-2017.
 */

public interface loginViewInterface {

    void setNavigation();
    void showMessage(int code);

    void showError( int errorCode);
}
